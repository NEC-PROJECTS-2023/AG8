from flask import Flask,render_template
from flask import request
import pickle
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
filename = 'savedmodel.sav'
classifier=pickle.load(open(filename,'rb'))

app=Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    if request.method=='POST':
        Title=request.form['Title']
        Author=request.form['Author']
        content=Author+" "+Title
        
        cv = TfidfVectorizer()
        cv.fit([content])

        X = cv.transform([content])
        print(X)

        prediction=classifier.predict(X)

        if (prediction=='1'):
            val='FAKE'
        else:
            val='REAl'

        return render_template('index.html',prediction=val)
if __name__=='__main__':
    app.run(debug=True)
