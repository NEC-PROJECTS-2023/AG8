import numpy as np
import pandas as pd
import re
import pickle
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

import nltk
nltk.download('stopwords')

dataset = pd.read_csv('train.csv',error_bad_lines=False,engine='python')

dataset.isnull().sum()
dataset = dataset.fillna('')

dataset['content'] = dataset['author']+' '+dataset['title']
dataset.to_csv('cleaned_dataset.csv',index=False)
df=pd.read_csv('cleaned_dataset.csv')
df = df.fillna('')
df.isnull().sum()

X = df.drop(columns='label', axis=1)
Y = df['label']


port_stem = PorterStemmer()
def stemming(content):
    stemmed_content = re.sub('[^a-zA-Z]',' ',str(content))
    stemmed_content = stemmed_content.lower()
    stemmed_content = stemmed_content.split()
    stemmed_content = [port_stem.stem(word) for word in stemmed_content if not word in stopwords.words('english')]
    stemmed_content = ' '.join(stemmed_content)
    return stemmed_content
df['content'] = df['content'].apply(stemming)


X =np.array(df['content'].values)
Y =np.array(df['label'].values)
vectorizer = TfidfVectorizer()
vectorizer.fit(X)

X = vectorizer.transform(X)

Title = input("Enter a Text: ")
Author = input("Enter a Text: ")
content = Author+" "+Title 
data = vectorizer.transform([content])

X = df['content'].values
Y = df['label'].values

vectorizer = TfidfVectorizer()
vectorizer.fit(X)

X = vectorizer.transform(X)

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state=2)

DTC=DecisionTreeClassifier()
DTC.fit(X_train,Y_train)


pickle.dump(RFC,open('spam.clf','wb'))
